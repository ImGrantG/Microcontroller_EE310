/* 
 * File:   Initialize.h
 * Author: Gramt
 *
 * Created on April 29, 2024, 11:01 PM
 */

#ifndef INITIALIZE_H
#define	INITIALIZE_H

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

#endif	/* INITIALIZE_H */

void initialize(void);
    
void initialize(void)
{
  
    TRISD = 0;
    ANSELD = 0;
    TRISA = 0xFF;
    ANSELA = 0;
    PORTD = 0;
    TRISC = 0;
    ANSELC = 0;
    PORTC = 0;
    TRISB = 0xFF;
    ANSELB = 0;
    int seg[4] = {0x3F,0x06,0x5B,0x4F};
    int disp = seg[0];
    int count = 0;
    int inp1,inp2;
    int SECRET_CODE = 32;
    int Input;
    PORTD = disp;
}