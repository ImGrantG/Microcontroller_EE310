/* 
 * File:   Functions.h
 * Author: Gramt
 *
 * Created on April 29, 2024, 10:54 PM
 */

#ifndef FUNCTIONS_H
#define	FUNCTIONS_H

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

#endif	/* FUNCTIONS_H */

void INTERRUPT_Initialize (void);
void Input1(void);
void Input2(void);

void Input1(void)
{
    int seg[4] = {0x3F,0x06,0x5B,0x4F};
    int disp = seg[0];
    int count = 0;
    int inp1,inp2;
    int SECRET_CODE = 32;
    int Input;
    PORTD = disp;
    while(1)
        
    {
        
        if(PORTAbits.RA4 == 0 && count < 3)
        {
            count += 1;
            disp = seg[count];
            PORTD = disp;
           _delay(1000000);
        }
        
        if(PORTAbits.RA0 == 1 && count != 0)
        {
            inp1 = 10*count;
            break;
        }
         
    }
}

void Input2(void)
{
    int seg[4] = {0x3F,0x06,0x5B,0x4F};
    int disp = seg[0];
    int count = 0;
    int inp1,inp2;
    int SECRET_CODE = 32;
    int Input;
    PORTD = disp;
    while(1)
    {
        
        if(PORTAbits.RA5 == 0 && count < 3)
        {
            count += 1;
            disp = seg[count];
            PORTD = disp;
           _delay(1000000);
        }
        
        if(PORTAbits.RA0 == 1 && count != 0)
        {
            inp2 = count;
            break;
        }

            
    }
   while(1)
   {

    Input = inp1 + inp2;
    if(Input == SECRET_CODE) PORTCbits.RC5 = 1;
    if(Input != SECRET_CODE) PORTCbits.RC7 = 1;
   }
}

void INTERRUPT_Initialize (void)
{
INTCON0bits.IPEN = 1;
INTCON0bits.GIEH = 1;
INTCON0bits.GIEL = 1;
INTCON0bits.INT0EDG = 1;
IPR1bits.INT0IP = 1;
PIE1bits.INT0IE = 1;
PIR1 = 0x0;
IVTBASEU = 0;
IVTBASEH = 0x40;
IVTBASEL = 0x08;
WPUB = 0xF;
}

void __interrupt(irq(IRQ_INT0),base(0x4008)) INT0_ISR(void)
{
    if(PIR1 == 0x1)
    {
        PORTCbits.RC3 = 1;
        _delay(250000);
        PORTCbits.RC3 = 0;
        _delay(250000);
        PORTCbits.RC3 = 1;
        _delay(250000);
        PORTCbits.RC3 = 0;
        _delay(250000);
        PORTCbits.RC3 = 1;
        _delay(250000);
        PORTCbits.RC3 = 0;
        _delay(250000);
        
    }
    PIR1 = 0;
}