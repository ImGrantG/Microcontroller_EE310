/*---------------------
 Title: Keypad.c
---------------------
Program Details: This Program Accepts a 4x4 keypad connection that
 utilizes it as a calculator and shows the individual inputs as well as the output
 on LEDs. There is also a reset button if asterisk on the keypad is pressed. The
 pound symbol is the equal button. A = Addition, B = Subtraction, C = Multiplication
 D = Division.
    
 Inputs: D4,D5,D6,D7
 Outputs: RD0,RD1,RD2,RD3,RB0,RB1,RB2,RB3,RB4,RB5,RB6,RB7
 Date: 11 April 2024
 File Dependencies / Libraries: Config.h
 Compiler: IDE v6.20
 Author: Grant Goodwin
 Versions:
       V1.0: Original Program
  */

#include <xc.h> // must have this
#include <stdlib.h>
//#include "../../../../../Program Files/Microchip/xc8/v2.40/pic/include/proc/pic18f46k42.h"
#include "C:/Program Files/Microchip/xc8/v2.46/pic/include/proc/pic18f47k42.h"
#include "Config.h"
#include "Functions.h"
#include "Initialize.h"
//#include "C:\Program Files\Microchip\xc8\v2.40\pic\include\proc\pic18f46k42"



#define _XTAL_FREQ 4000000                 // Fosc  frequency for _delay()  library
#define FCY    _XTAL_FREQ/4


void main (void){
    initialize();
    
    INTERRUPT_Initialize();
    
    Input1();
    
    Input2();
    
    
}


